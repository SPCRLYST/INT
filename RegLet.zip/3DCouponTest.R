library(ggplot2)
library(RColorBrewer)
library(zoo)
library(RCurl)
library(XML)
library(xts)
library(plyr)
library(reshape2)
library(ReporteRs)
require(lubridate)
library(scales)
library(grid)
library(gridExtra)
library(TTR)
library(scatterplot3d)
require(rgl)
require(RColorBrewer)

#NA removal function
completeFunc <- function(data, desiredCols) 
{
  completeVec <- complete.cases(data[, desiredCols])
  return(data[completeVec, ])
} 

#coupon data
CoupURL <- getURL("https://raw.githubusercontent.com/SPCRLYST/CouponProj/master/FinalFIUtilities.csv")
coupdata <- read.csv(text = CoupURL)
#US treasury data
USTreasURL <- getURL("https://raw.githubusercontent.com/SPCRLYST/CouponProj/master/USTreasuries.csv")
USTreasdata <- read.csv(text = USTreasURL)

#renaming treasury columns and fixing dates
USTreas <- USTreasdata
USTreas$Date <- as.Date(as.character(USTreas$Date), format="%b-%d-%Y")
USTreas <- rename(USTreas, c("UST...20.Year"="UST20","UST...10.Year"="UST10","UST...5.Year"="UST5",
                             "UST...1.Year"="UST1"))

#US Companies Only
coupdata <- subset(coupdata, Country == c("United States"))

#formating the date to plot time series
coupdata$MaturityDate <- as.Date(as.character(coupdata$MaturityDate), format="%m/%d/%Y")
coupdata$OfferingDate <- as.Date(as.character(coupdata$OfferingDate), format="%m/%d/%Y")
#formating offering amount as number
coupdata$OfferingAmount <- as.numeric(as.character(coupdata$OfferingAmount))

#creating term variable
coupdata$odyear <- strftime(coupdata$OfferingDate, "%Y")
coupdata$mdyear <- strftime(coupdata$MaturityDate, "%Y")
coupdata$term <- as.numeric(coupdata$mdyear) - as.numeric(coupdata$odyear)

#higher level rating
coupdata$oRating <- coupdata$Rating
coupdata$oRating[coupdata$oRating == "AAA-"] <- "AAA"
coupdata$oRating[coupdata$oRating == "AA+"] <- "AA"
coupdata$oRating[coupdata$oRating == "AA-"] <- "AA"
coupdata$oRating[coupdata$oRating == "A+"] <- "A"
coupdata$oRating[coupdata$oRating == "A-"] <- "A"
coupdata$oRating[coupdata$oRating == "BBB+"] <- "BBB"
coupdata$oRating[coupdata$oRating == "BBB-"] <- "BBB"
coupdata$oRating[coupdata$oRating == "BB+"] <- "BB"
coupdata$oRating[coupdata$oRating == "BB-"] <- "BB"
coupdata$oRating[coupdata$oRating == "B+"] <- "B"
coupdata$oRating[coupdata$oRating == "B-"] <- "B"

#keeping only issuances greater than 1 million
coupdata <- subset(coupdata, OfferingAmount >= 1)

#remove NA's
coupdata <- completeFunc(coupdata,"OfferingAmount")
hist(coupdata$OfferingAmount)
quantile(coupdata$OfferingAmount, c(.10,.30,.50,.70,.90))
#structuring the amount data
coupdata$fAmount <- ""
coupdata$fAmount[coupdata$OfferingAmount > 500] <- c("Very Large")
coupdata$fAmount[coupdata$OfferingAmount <= 500 & coupdata$OfferingAmount > 250] <- c("Large")
coupdata$fAmount[coupdata$OfferingAmount <= 250 & coupdata$OfferingAmount > 100] <- c("Medium")
coupdata$fAmount[coupdata$OfferingAmount <= 100 &  coupdata$OfferingAmount > 10] <- c("Small")
coupdata$fAmount[coupdata$OfferingAmount <= 10 &  coupdata$OfferingAmount > 0] <- c("Very Small")
coupdata$fAmount <- as.factor(coupdata$fAmount)
#structuring the term
coupdata$fterm <- ""
coupdata$fterm[coupdata$term > 19] <- c("Long-term")
coupdata$fterm[coupdata$term <= 19 & coupdata$term > 4] <- c("Medium-term")
coupdata$fterm[coupdata$term <= 4] <- c("Short-term")
coupdata$fterm <- as.factor(coupdata$fterm)

#structuring the subordination data
coupdata$level <- coupdata$SeniorityLevel
coupdata$level <- as.character(coupdata$level)
coupdata$level[coupdata$level == "Junior Subordinate"] <- "Other"
coupdata$level[coupdata$level == "Not Ranked"] <- "Other"
coupdata$level[coupdata$level == "Senior Subordinate"] <- "Other"
coupdata$level[coupdata$level == "Subordinate"] <- "Other"
coupdata$level <- as.factor(coupdata$level)

#creating offering amount per term
coupdata$year_debt <- coupdata$OfferingAmount/coupdata$term
aggregate(OfferingAmount ~ odyear , coupdata, FUN = sum)

#getting a data frame of main regulated industries
regutil <- subset(coupdata, PrimaryIndustry == c("Electric Utilities") | PrimaryIndustry == c("Multi-Utilities") |
                    PrimaryIndustry == c("Water Utilities") | PrimaryIndustry == c("Gas Utilities"))

#breaking out year to build the term variable
regutil$State <- regutil$State.RegionFromPrimaryAddress
regutil$State.RegionFromPrimaryAddress <- NULL

#long-term data frame
lt_regutil <- subset(regutil, term >= 20)
#medium-term 10-20 data frame
mt1_regutil <- subset(regutil, term <20 & term >=10)
#medium-term 5-10 data frame
mt2_regutil <- subset(regutil, term <10 & term >=5)
#short-term data frame
st_regutil <- subset(regutil, term <5)

#coloring for amount levels
#amnt_coloring <- c(large,medium,small,very large,very small)
amnt_coloring <- c("#6666FF","#FF6600","#99FF33","#0000CC","#FFFF66")
#coloring for amount levels
#term_coloring <- c("","","")
term_coloring <- c("#CC0000","#CC9900","#339999")

d_term_coloring <- c("#CC0000","#CC9900","#339999")
plot3d(regutil$OfferingDate,
	 regutil$CouponatOffer, 
	 regutil$OfferingAmount,	 
	 col = d_term_coloring[as.numeric(regutil$fterm)],
	 size =8)

#	 color = d_term_coloring,
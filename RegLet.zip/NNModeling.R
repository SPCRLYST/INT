#####Reading in data
library(ggplot2)
library(RColorBrewer)
library(zoo)
library(RCurl)
library(plyr)
library(reshape2)
require(lubridate)
library(scales)
library(grid)
library(gridExtra)
library(TTR)
library(neuralnet)
library(NeuralNetTools)
library(dplyr)

#NA removal function
completeFunc <- function(data, desiredCols) 
{
  completeVec <- complete.cases(data[, desiredCols])
  return(data[completeVec, ])
} 
#Normalizing data function
normalize <- function(x){ 
  return((x - min(x)) / (max(x) - min(x))) 
}
#Denormalize data function
denormalize <- function(x,minval,maxval){
  x*(maxval-minval) + minval
}

#Seed number
seed = 33

#econ data
ECONURL <- getURL("https://raw.githubusercontent.com/SPCRLYST/NeuralProj/master/MacroF.csv")
ECONdata <- read.csv(text = ECONURL)
ECONdata <- ECONdata[c('Year','Year1REAL.GDP','Year1ConsSpending','Year1EquipInvest','Year1NonresCons',
                     'Year1ResCons','Year1CPI','Year1Unemp')] 
#coupon data
NNURL <- getURL("https://raw.githubusercontent.com/SPCRLYST/NeuralProj/master/NeuralNetProj.csv")
NNdata <- read.csv(text = NNURL)
str(NNdata)
names(NNdata)

#merge econ and nndata
NNdata <- merge(NNdata,ECONdata,by.x = "Year", by.y = "Year")

#converting factor data to numeric data
NNdata$YearROE <- as.numeric(NNdata$YearROE) 
NNdata$Year2ROE <- as.numeric(NNdata$Year2ROE) 
NNdata$Year3ROE <- as.numeric(NNdata$Year3ROE) 
NNdata$YearDebt_EBITDA <- as.numeric(NNdata$YearDebt_EBITDA) 
NNdata$Year2Debt_EBITDA <- as.numeric(NNdata$Year2Debt_EBITDA) 
NNdata$Year3Debt_EBITDA <- as.numeric(NNdata$Year3Debt_EBITDA) 
NNdata$YearFFO_Debt <- as.numeric(NNdata$YearFFO_Debt) 
NNdata$Year2FFO_Debt <- as.numeric(NNdata$Year2FFO_Debt) 
NNdata$Year3FFO_Debt <- as.numeric(NNdata$Year3FFO_Debt)

#Fixing FFO_Debt and Debt_EBITDA
NNdata$YearROE <- NNdata$YearROE/100
NNdata$Year2ROE <- NNdata$Year2ROE/100
NNdata$Year3ROE <- NNdata$Year3ROE/100
NNdata$YearDebt_EBITDA <- NNdata$YearDebt_EBITDA/100
NNdata$Year2Debt_EBITDA <- NNdata$Year2Debt_EBITDA/100
NNdata$Year3Debt_EBITDA <- NNdata$Year3Debt_EBITDA/100
NNdata$YearFFO_Debt <- NNdata$YearFFO_Debt/100
NNdata$Year2FFO_Debt <- NNdata$Year2FFO_Debt/100
NNdata$Year3FFO_Debt <- NNdata$Year3FFO_Debt/100

#Getting the max and mins of the original data set
minvec <- min(NNdata$EBITDA)
maxvec <- max(NNdata$EBITDA)

#Randomizing the data set
set.seed(seed)
#Indexing the dataframes
per = 0.80
index <- sample(1:nrow(NNdata),round(per*nrow(NNdata)))

#Revoming company name categoricals
NNdata[1:5] <- list(NULL)
names(NNdata)
NNdata[22:239] <- list(NULL)
names(NNdata)

#Checking for missing values may be necessary to replace missing values
apply(NNdata,2,function(x) sum(is.na(x)))

#Breaking out the data set for LM training and test
LMtrain <- NNdata[index,]
LMtest <- NNdata[-index,]
#LM model test
EBITDA_LModel <- glm(EBITDA~.,data=LMtrain)
summary(EBITDA_LModel)
#Predicting LM Model
EBITDA_estLM <- predict(EBITDA_LModel,LMtest)
MSE.lm <- sum((EBITDA_estLM - LMtest$EBITDA)^2)/nrow(LMtest)
#LM correlation and result plot
cor(EBITDA_estLM, LMtest$EBITDA)
plot(EBITDA_estLM)

#Normalizing data for NN
NNdataN <-NNdata %>%
         mutate_each(funs(normalize), EBITDA , YearRev , Year2Rev , Year3Rev , YearOpExp , Year2OpExp , 
              Year3OpExp , YearCapex , Year2Capex , Year3Capex , YearDiv , Year2Div , Year3Div, YearROE , Year2ROE ,
              Year3ROE , YearDebt_EBITDA, Year2Debt_EBITDA , Year3Debt_EBITDA , YearFFO_Debt , Year2FFO_Debt, Year1REAL.GDP, 
              Year1ConsSpending , Year1EquipInvest , Year1NonresCons , Year1ResCons , Year1CPI, Year1Unemp)
str(NNdataN, list.len=ncol(NNdataN))

#Randomizing the data set
set.seed(seed)
NNdataNorm <- NNdataN[sample(1:nrow(NNdataN)),]

#Breaking out the data set for training and test
NNtrainN <- NNdataNorm[1:1910,]
NNtestN <- NNdataNorm[1911:2387,]

#Getting the column names for the neural net
n <- names(NNtrainN[1:28])
f <- as.formula(paste("EBITDA ~", paste(n[!n %in% "EBITDA"], collapse = " + ")))

#Building the NN model
EBITDA_NNmodel <- neuralnet(f, data = NNtrainN, hidden = c(25), linear.output = F)
NNPlot <- plot(EBITDA_NNmodel)
plotnet(EBITDA_NNmodel, alpha = 0.6)

#Forecasting the test data set with the NN model
NNResults <- neuralnet::compute(EBITDA_NNmodel, NNtestN[2:28])
#Viewing the result of the NN model
cor(NNResults$net.result, NNtestN$EBITDA)
plot(NNResults$net.result)
#Creating data frame of forecast NN EBITDA figures
EstEBITDA <- as.data.frame(NNResults$net.result)

#Denormalizing the data
NNdataAns <- as.data.frame(Map(denormalize,EstEBITDA,minvec,maxvec))
NNtestEBITDA <- as.data.frame(NNtestN$EBITDA)
NNtestEBITDA <- as.data.frame(Map(denormalize,NNtestEBITDA,minvec,maxvec))

#Mean Square Error calculation for NN
MSE.nn <- sum((NNdataAns$V1 - NNtestEBITDA)^2)/nrow(NNtestN)
print(paste(MSE.lm,MSE.nn))

#Plots for LM and NN models
#Combinded plot
par(mfrow=c(1,1))
plot(NNtestEBITDA$NNtestN.EBITDA,NNdataAns$V1,col='red',main='Real vs Predicted EBITDA NN',pch=18,cex=0.7)
abline(0,1,lwd=2)
legend('bottomright',legend='NN',pch=18,col='red', bty='n')
plot(LMtest$EBITDA,EBITDA_estLM,col='blue',main='Real vs Predicted EBITDA LM',pch=18, cex=0.7)
abline(0,1,lwd=2)
legend('bottomright',legend='LM',pch=18,col='blue', bty='n', cex=.95)
plot(NNtestEBITDA$NNtestN.EBITDA,NNdataAns$V1,xlab = "Known Test EBITDA",ylab = "EBITDA Estimate",col='red',main='Real vs Predicted NN',pch=18,cex=0.7)
points(LMtest$EBITDA,EBITDA_estLM,col='blue',pch=18,cex=0.7)
abline(0,1,lwd=2)
legend('bottomright',legend=c('NN','LM'),pch=18,col=c('red','blue'))





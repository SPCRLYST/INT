#####Reading in data
library(ggplot2)
library(RColorBrewer)
library(zoo)
library(RCurl)
library(XML)
library(xts)
library(plyr)
library(reshape2)
library(ReporteRs)
library(lubridate)
library(scales)
library(grid)
library(gridExtra)
library(TTR)
library(scatterplot3d)
library(cowplot)

#NA removal function
completeFunc <- function(data, desiredCols) 
{
  completeVec <- complete.cases(data[, desiredCols])
  return(data[completeVec, ])
} 
#Custom removal of legends
g_legend <- function(a.gplot)
{
  tmp <- ggplot_gtable(ggplot_build(a.gplot))
  leg <- which(sapply(tmp$grobs, function(x) x$name) == "guide-box")
  legend <- tmp$grobs[[leg]]
  return(legend) 
}

#coupon data
CoupURL <- getURL("https://raw.githubusercontent.com/SPCRLYST/CouponProj/master/FinalFIUtilities.csv")
coupdata <- read.csv(text = CoupURL)
#US treasury data
USTreasURL <- getURL("https://raw.githubusercontent.com/SPCRLYST/CouponProj/master/USTreasuries.csv")
USTreasdata <- read.csv(text = USTreasURL)

#renaming treasury columns and fixing dates
USTreas <- USTreasdata
USTreas$Date <- as.Date(as.character(USTreas$Date), format="%b-%d-%Y")
USTreas <- rename(USTreas, c("UST...20.Year"="UST20","UST...10.Year"="UST10","UST...5.Year"="UST5",
                             "UST...1.Year"="UST1"))

#US Companies Only
#coupdata <- subset(coupdata, Country == c("United States"))

#formating the date to plot time series
coupdata$MaturityDate <- as.Date(as.character(coupdata$MaturityDate), format="%m/%d/%Y")
coupdata$OfferingDate <- as.Date(as.character(coupdata$OfferingDate), format="%m/%d/%Y")
#formating offering amount as number
coupdata$OfferingAmount <- as.numeric(as.character(coupdata$OfferingAmount))

#creating date variables variable
coupdata$odyear <- strftime(coupdata$OfferingDate, "%Y")
coupdata$odmyear <- as.Date(cut(coupdata$OfferingDate, breaks = "month"))
coupdata$mdyear <- strftime(coupdata$MaturityDate, "%Y")
coupdata$mdmyear <- as.Date(cut(coupdata$MaturityDate, breaks = "month"))
#finding the term of an issuance
coupdata$term <- as.numeric(coupdata$mdyear) - as.numeric(coupdata$odyear)

#higher level rating
coupdata$oRating <- coupdata$Rating
coupdata$oRating[coupdata$oRating == "AAA-"] <- "AAA"
coupdata$oRating[coupdata$oRating == "AA+"] <- "AA"
coupdata$oRating[coupdata$oRating == "AA-"] <- "AA"
coupdata$oRating[coupdata$oRating == "A+"] <- "A"
coupdata$oRating[coupdata$oRating == "A-"] <- "A"
coupdata$oRating[coupdata$oRating == "BBB+"] <- "BBB"
coupdata$oRating[coupdata$oRating == "BBB-"] <- "BBB"
coupdata$oRating[coupdata$oRating == "BB+"] <- "BB"
coupdata$oRating[coupdata$oRating == "BB-"] <- "BB"
coupdata$oRating[coupdata$oRating == "B+"] <- "B"
coupdata$oRating[coupdata$oRating == "B-"] <- "B"

#keeping only issuances greater than 1 million
coupdata <- subset(coupdata, OfferingAmount >= 1)

#remove NA's
coupdata <- completeFunc(coupdata,"OfferingAmount")
hist(coupdata$OfferingAmount)
quantile(coupdata$OfferingAmount, c(.10,.30,.50,.70,.90))
#structuring the amount data
coupdata$fAmount <- ""
coupdata$fAmount[coupdata$OfferingAmount > 500] <- c("Very Large")
coupdata$fAmount[coupdata$OfferingAmount <= 500 & coupdata$OfferingAmount > 250] <- c("Large")
coupdata$fAmount[coupdata$OfferingAmount <= 250 & coupdata$OfferingAmount > 100] <- c("Medium")
coupdata$fAmount[coupdata$OfferingAmount <= 100 &  coupdata$OfferingAmount > 10] <- c("Small")
coupdata$fAmount[coupdata$OfferingAmount <= 10 &  coupdata$OfferingAmount > 0] <- c("Very Small")
coupdata$fAmount <- as.factor(coupdata$fAmount)
#structuring the term
coupdata$fterm <- ""
coupdata$fterm[coupdata$term > 19] <- c("Long-term")
coupdata$fterm[coupdata$term <= 19 & coupdata$term > 4] <- c("Medium-term")
coupdata$fterm[coupdata$term <= 4] <- c("Short-term")
coupdata$fterm <- as.factor(coupdata$fterm)

#structuring the subordination data
coupdata$level <- coupdata$SeniorityLevel
coupdata$level <- as.character(coupdata$level)
coupdata$level[coupdata$level == "Junior Subordinate"] <- "Other"
coupdata$level[coupdata$level == "Not Ranked"] <- "Other"
coupdata$level[coupdata$level == "Senior Subordinate"] <- "Other"
coupdata$level[coupdata$level == "Subordinate"] <- "Other"
coupdata$level <- as.factor(coupdata$level)

regutil <- coupdata

#creating offering amount per term
totoffamnt <- aggregate(OfferingAmount ~ odyear, regutil, FUN = sum)
aveterm <- aggregate(term ~ odyear, regutil, FUN = mean)
avecoup <- aggregate(CouponatOffer ~ odyear, regutil, FUN = mean)

#getting a data frame of main regulated industries
#regutil <- subset(coupdata, PrimaryIndustry == c("Electric Utilities") | PrimaryIndustry == c("Multi-Utilities") |
#                    PrimaryIndustry == c("Water Utilities") | PrimaryIndustry == c("Gas Utilities"))

#breaking out year to build the term variable
regutil$State <- regutil$State.RegionFromPrimaryAddress
regutil$State.RegionFromPrimaryAddress <- NULL

#adding yearly debt totals to regutil
regutil <- (merge(totoffamnt, regutil, by = 'odyear'))
regutil <- rename(regutil, c("OfferingAmount.x"="YearOffAmnt"))
regutil <- rename(regutil, c("OfferingAmount.y"="OfferingAmount"))

regutil$woamnt <- regutil$OfferingAmount/regutil$YearOffAmnt
#weighted term
regutil$woaterm <- regutil$woamnt*regutil$term
woterm <- aggregate(woaterm ~ odyear, regutil, FUN = sum)
woterm$woaterm <- round(woterm$woaterm, digits = 3)
woterm <- merge(aveterm, woterm, by = 'odyear')
woterm <- merge(totoffamnt, woterm, by = 'odyear')
write.csv(woterm,"E:/Commentaries/CouponComm/woterm.csv")
#weighted coupon
regutil$wocoup <- regutil$woamnt*regutil$CouponatOffer
wocoupn <- aggregate(wocoup ~ odyear, regutil, FUN = sum)
wocoupn$wocoup <- round(wocoupn$wocoup, digits = 2)
wocoupn <- merge(avecoup, wocoupn, by = 'odyear')
wocoupn <- merge(totoffamnt, wocoupn, by ='odyear')
write.csv(wocoupn,"E:/Commentaries/CouponComm/wocoupn.csv")
#complete bar plots for average weighted term
ggplot(woterm, aes(x = odyear, y = woaterm)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  geom_text(aes(label = woaterm), vjust = 1.6, 
            color = "white", position = position_dodge(0.9), size = 2.5)+
  theme_minimal()+
  theme(legend.position = "bottom",
        axis.text.x = element_text(angle = 45),
        text = element_text(size = 11))+
  xlab("\nCalendar Year")+
  ylab("Years")+
  ggtitle("Annual Average Weighted Duration")
#complete bar plots for average weighted coupon
ggplot(wocoupn, aes(x = odyear, y = wocoup)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  geom_text(aes(label = wocoup), vjust = 1.6, 
            color = "white", position = position_dodge(0.9), size = 2.5)+
  theme_minimal()+
  theme(legend.position = "bottom",
        axis.text.x = element_text(angle = 45),
        text = element_text(size = 11))+
  xlab("\nCalendar Year")+
  ylab("Average Weighted Coupon (%)")+
  ggtitle("Annual Average Weighted Coupon")

#adding weighted average to regutil data frame
regutil <- merge(regutil, wocoupn, by = 'odyear')
colnames(regutil)[colnames(regutil) == "OfferingAmount.y"] <- "TotalYDebt"
colnames(regutil)[colnames(regutil) == "OfferingAmount.x"] <- "OfferingAmount"
colnames(regutil)[colnames(regutil) == "wocoup.x"] <- "wocoup"
colnames(regutil)[colnames(regutil) == "wocoup.y"] <- "YearWCoup"
colnames(regutil)[colnames(regutil) == "CouponatOffer.x"] <- "CouponatOffer"
regutil$CouponatOffer.y <- NULL
regutil$YearOffAmnt <- NULL

#coloring for amount levels
#amnt_coloring <- c(large,medium,small,very large,very small)
amnt_coloring <- c("#6666FF","#FF6600","#99FF33","#0000CC","#FFFF66")
#coloring for amount levels
term_coloring <- c("#CC0000","#CC9900","#339999")
#coloring for amount rating level
rate_color <- brewer.pal(11,"Spectral")
#monthly rate color
# #3288BD , #5E4FA2 
month_color <- c("#F46D43","#FDAE61","#FEE08B","#3288BD")
#coloring for amount term
term_color <- brewer.pal(3,"Spectral")

#plot to get weighted average coupon legend
#http://stackoverflow.com/questions/13143894/how-do-i-position-two-legends-independently-in-ggplot
ywcoups <- ggplot(data = regutil)+
  geom_line(aes(x = OfferingDate, y = YearWCoup, lty = ''), 
            colour = "black", size = 1)+
  scale_linetype('Weigthed Average Coupon')+
  theme_minimal()+
  theme(legend.position = "bottom",
        axis.text.x = element_text(angle = 45),
        text = element_text(size = 11))+
  xlab("\nYear")+
  scale_y_continuous(limits = c(0,15))+
  ylab("Coupon at Offering (%)\n")+
  scale_x_date(date_breaks = "years", date_labels = "%Y")
  scale_colour_manual(values = c("black"))
adj_ywcoups <-  ywcoups + coord_cartesian(xlim=c(as.Date("1995-01-01"),as.Date("2016-04-01")))
adj_ywcoups
wcoupleg <- g_legend(adj_ywcoups)
#ggplot of all coupon information by amount at offering
#yearly debt issues
debtiss <- ggplot(data = regutil, aes(x = OfferingDate))+
  geom_line(aes(y = (TotalYDebt/1000), fill = "Total Annual Debt"), 
            colour = "darkgoldenrod4", size = .75)+
  theme_minimal()+
  theme(legend.position = "bottom",
        axis.text.x = element_blank(),
        axis.title.x = element_blank(),
        text = element_text(size = 11))+
  scale_y_continuous(limits = c(0,65))+
  ylab("Debt Issued (USD billions)\n\n")+
  scale_x_date(date_breaks = "years")
adj_debtiss <- debtiss + coord_cartesian(xlim=c(as.Date("1995-01-01"),as.Date("2017-04-01")))
adj_debtiss
########################################################################################
#useful charts
########################################################################################
#scatter plot of coupons
aallcoups <- ggplot(data = regutil, aes(x = OfferingDate))+
  geom_point(aes(y = CouponatOffer, colour = fAmount))+
  scale_colour_manual(name  = "Offering Amount", 
                      breaks = c('Very Large','Large','Medium','Small','Very Small'),
                      labels = c('Very Large','Large','Medium','Small','Very Small'),
                      values = amnt_coloring)+
  geom_line(aes(y = YearWCoup), colour = "black", size = 1)+
  theme_minimal()+
  theme(legend.position = "bottom",
        axis.text.x = element_text(angle = 45),
        text = element_text(size = 11))+
  xlab("\nYear")+
  scale_y_continuous(limits = c(0,15))+
  ylab("Coupon at Offering (%)\n")+
  scale_x_date(date_breaks = "years", date_labels = "%Y")
adj_aall <- aallcoups + coord_cartesian(xlim=c(as.Date("1995-01-01"),as.Date("2016-08-01"))) 
adj_aall
acoupleg <- g_legend(adj_aall)
# setup legends grid 
wcoupleg_grid <- cowplot::plot_grid(wcoupleg, align = "h", nrow = 1)
# add second legend to grid, specifying its location 
coup_legends <- wcoupleg_grid + 
                ggplot2::annotation_custom(grob = acoupleg, xmin = 0.5, 
                                           xmax = 0.5, ymin = 0.1, 
                                           ymax = 0.1)
plot(coup_legends)
#combining the two graphs
grid.newpage()
grid.draw(rbind(ggplotGrob(adj_debtiss),ggplotGrob(adj_aall), size = "last"))
#debt issued by rating
#can us odyear (year) or odmyear (month year)
regutil <- with(regutil, regutil[order(odyear, oRating),])
ggplot(regutil, aes(x = odyear, 
                   y = OfferingAmount/1000, 
                   fill = oRating)) +
  geom_bar(stat = "identity", position = "stack") +
  theme_minimal()+
  theme(legend.position = "bottom",
        axis.text.x = element_text(angle = 45),
        text = element_text(size = 11))+
  labs(title = "Annual Debt Issuance by Rating", 
       x = "", 
       y = "Debt Issuances (USD billions)\n")+
  scale_y_continuous(limits = c(0,65))+
  scale_fill_manual(values = rate_color,
                    name = "Rating of Issuances",
                    breaks = c("AAA","AA","A","BBB","BB","B","CCC","CC","C","D","Unknown"),
                    labels = c("AAA","AA","A","BBB","BB","B","CCC","CC","C","D","Unknown"))
write.csv(regutil,"E:/Commentaries/CouponComm/regutildebt.csv")
#monthly version
month_regutil <- subset(regutil, OfferingDate>="2014-01-01" & OfferingDate<="2017-02-16")
month_regutil <- with(month_regutil, month_regutil[order(odmyear, oRating),])
mondebt <- ggplot(month_regutil, aes(x = odmyear, 
                    y = OfferingAmount/1000, 
                    fill = oRating)) +
  geom_bar(stat = "identity", position = "stack") +
  theme_minimal()+
  theme(legend.position = "bottom",
        axis.text.x = element_text(angle = 90),
        text = element_text(size = 11))+
  labs(title = "Monthly Debt Issuance by Rating", 
       x = "", 
       y = "Debt Issuances (USD billions)\n")+
  scale_y_continuous(limits = c(0,20))+
  scale_x_date(labels = date_format("%m-%Y"),date_breaks = "1 month")+
  scale_fill_manual(values = month_color,
                    name = "Rating of Issuances",
                    breaks = c("AAA","AA","A","BBB","BB","B","CCC","CC","C","D","Unknown"),
                    labels = c("AAA","AA","A","BBB","BB","B","CCC","CC","C","D","Unknown"))
mon_adj <- mondebt + coord_cartesian(xlim=c(as.Date("2014-02-01"),as.Date("2017-01-01"))) 
mon_adj
write.csv(month_regutil,"E:/Commentaries/CouponComm/monthlydebt.csv")
#debt issued by term
regutil <- with(regutil, regutil[order(odyear, fterm),])
ggplot(regutil, aes(x = odyear, 
                    y = OfferingAmount/1000, 
                    fill = fterm)) +
  geom_bar(stat = "identity", position = "stack") +
  theme_minimal()+
  theme(legend.position = "bottom",
        axis.text.x = element_text(angle = 45),
        text = element_text(size = 11))+
  labs(title = "Debt Issuance by Term", 
       x = "", 
       y = "Debt Issuances (USD billions)\n")+
  scale_y_continuous(limits = c(0,65))+
  scale_fill_manual(values = term_color,
                    name = "Term of Issuances",
                    breaks = c("Long-term","Medium-term","Short-term"),
                    labels = c("Long-term","Medium-term","Short-term"))
########################################################################################

#ggplot of all coupon information by term at offering
termcoups <- ggplot(regutil, aes(x = OfferingDate))+
  geom_point(aes(y = CouponatOffer, colour = fterm))+
  scale_colour_manual(name  = "Maturity", 
                      breaks = c('Long-term','Medium-term','Short-term'),
                      labels = c('Long-term (20+ years)','Medium-term (19-5 years)','Short-term (0+ years)'),
                      values = term_coloring)+
  geom_line(aes(y = YearWCoup), colour = "black", size = 1)+
  theme_minimal()+
  theme(legend.position = "bottom",
        axis.text.x = element_text(angle = 45),
        text = element_text(size = 11))+
  xlab("\nYear")+
  scale_y_continuous(limits = c(0,15))+
  ylab("Coupon at Offering (%)\n")+
  scale_x_date(date_breaks = "years", date_labels = "%Y")
adj_termcoups <- termcoups + coord_cartesian(xlim=c(as.Date("1995-01-01"),as.Date("2016-04-01")))
adj_termcoups
#combining the two graphs
grid.newpage()
grid.draw(rbind(ggplotGrob(adj_debtiss),ggplotGrob(adj_termcoups), size = "last"))

#3D plot attempt
d_term_coloring <- c("#CC0000","#CC9900","#339999")
d_term_coloring <- d_term_coloring[as.numeric(regutil$fterm)]
scatterplot3d(regutil$OfferingDate,regutil$OfferingAmount,regutil$CouponatOffer, angle = 25, 
              pch = 16, color = d_term_coloring, grid = TRUE, box = FALSE)

#ggplot of all coupon information by rating
rating_coloring <- c("#3399FF","#3366CC","#003399","#FF6600","#FF9900","#F0E442","#CC00CC","#66FF00","#999999")
rallcoups <- ggplot(regutil, aes(OfferingDate,CouponatOffer, colour = oRating))+
  geom_point()+
  scale_colour_manual(name  = "Rating", 
                      breaks = c('AAA','AA','A','BBB','BB','B','CC','D','Unknown'),
                      labels = c('AAA','AA','A','BBB','BB','B','CC','D','Unknown'),
                      values = rating_coloring)+
  geom_smooth(colour = 'black')+
  theme_minimal()+
  theme(legend.position = "bottom",
        axis.text.x = element_text(angle = 45),
        text = element_text(size = 11))+
  xlab("\nYear")+
  scale_y_continuous(limits = c(0,15))+
  ylab("Coupon at Offering (%)\n")+
  scale_x_date(date_breaks = "years", date_labels = "%Y")
plot(rallcoups)
adj_rall <- rallcoups + coord_cartesian(xlim=c(as.Date("1995-01-01"),as.Date("2016-04-01")))
adj_rall

#ggplot of know information for coupons industry
indcoups <- ggplot(regutil, aes(OfferingDate,CouponatOffer,colour = fAmount))+
              facet_wrap(~PrimaryIndustry,ncol=2)+
              geom_point()+
              scale_colour_manual(name  = "Offering Amount", 
                      breaks = c('Large','Medium','Small'),
                      labels = c('Large','Medium','Small'),
                      values = amnt_coloring)+
              geom_smooth(colour = 'black')+
              theme_minimal()+
              theme(legend.position = "bottom")+
              xlab("Year")+
              scale_y_continuous(limits = c(0,15))+
              ylab("Coupon at Offering (%)")
plot(indcoups)

#ggplot of know information for coupons senority
ggplot(regutil, aes(OfferingDate,CouponatOffer,colour = fAmount))+
  facet_grid(level~fAmount)+
  geom_point()+
  scale_colour_manual(name  = "Offering Amount", 
                      breaks = c('Large','Medium','Small'),
                      labels = c('Large','Medium','Small'),
                      values = amnt_coloring)+
  theme_minimal()+
  theme(legend.position = "bottom",
        axis.text.x = element_text(angle = 45),
        text = element_text(size = 11))+
  ylab("Coupon at Offering (%)\n")+
  scale_y_continuous(limits = c(0,15))
  
#ggplot of know information for coupons term
ggplot(regutil, aes(OfferingDate,CouponatOffer,colour = term))+
  scale_y_continuous(limits = c(0,15))+
  geom_point()

#ggplot of know information for coupons term
ggplot(regutil, aes(OfferingDate,term,colour = term))+
  geom_point()

#ggplot of US treasury rates
UStreas <- ggplot(USTreas, aes(Date))+
  scale_y_continuous(limits = c(0,10))+
  geom_line(aes(y = UST20, colour = "20 year"))+
  geom_line(aes(y = UST10, colour = "10 year"))+
  geom_line(aes(y = UST5, colour = "5 year"))+
  scale_colour_manual(name = "US Treasury Maturity",
                      values=c("gray80","gray10","gray50"))+
  theme_minimal()+
  theme(legend.position = "bottom",
        axis.text.x = element_text(angle = 45),
        text = element_text(size = 11))+
  scale_x_date(date_breaks = "years", date_labels = "%Y")+
  xlab("\nYear")+
  ylab("Interest Rates (%)\n")+
  ggtitle("US Treasury Interest Rates")
plot(UStreas)
adjUStreas <- UStreas + coord_cartesian(xlim=c(as.Date("1995-01-01"),as.Date("2016-04-01")))
adjUStreas

#ggplot of know information for coupons term
ggplot(regutil, aes(odyear,term))+
  geom_violin()

#monthly average data frame of treasury rates
tmonth <- strftime(USTreas$Date, "%m")
tyear <- strftime(USTreas$Date, "%Y")
#avetreastot <- (USTreas$UST20+USTreas$UST10+USTreas$UST5)/3
mnthtreas <- data.frame(USTreas$Date, USTreas$UST10, tmonth, tyear)
mnthtreas$Date <- mnthtreas$USTreas.Date
mnthtreas$USTreas.Date <- NULL
mnthtreas$UST10<- mnthtreas$USTreas.UST10
mnthtreas$USTreas.UST10 <- NULL
mnthtreas <- aggregate(UST10 ~ tmonth + tyear, mnthtreas, FUN = mean)
mnthtreas$date <- as.POSIXct(paste(mnthtreas$tyear, mnthtreas$tmonth, "01", sep = "-"))

#monthly average data frame of reg utility coupon data set
month <- strftime(regutil$OfferingDate, "%m")
year <- strftime(regutil$OfferingDate, "%Y")
mnthregucoup <- data.frame(regutil$OfferingDate, regutil$CouponatOffer, regutil$term, month, year)
mnthregucoup$coupon <- mnthregucoup$regutil.CouponatOffer
mnthregucoup$regutil.CouponatOffer <- NULL
mnthregucoup$term <- mnthregucoup$regutil.term
mnthregucoup$regutil.term <- NULL
mnthregucoup <- subset(mnthregucoup, term >= 10)
mnthregucoup$term <- NULL
mnthregucoup <- aggregate(coupon ~ month + year, mnthregucoup, FUN = mean)
mnthregucoup$date <- as.POSIXct(paste(mnthregucoup$year, mnthregucoup$month, "01", sep = "-"))

##ggplot for mean forecast treasury  
treas_plot <- ggplot(mnthtreas, aes(x = as.Date(mnthtreas$date), y = mnthtreas$avetreastot))+ 
  geom_line(colour = 'black')+
  theme_minimal()+
  theme(legend.position = "bottom",
        axis.text.x = element_text(angle = 45),
        text = element_text(size = 11))+
  scale_x_date(date_breaks = "years", date_labels = "%Y")+
  xlab("\nYear")+
  ylab("Interest Rates (%)\n")+
  scale_y_continuous(limits = c(0,15))+
  labs(title = "Average US Treasury Interest Rate: 20 year, 10 year, and 5 year")
plot(treas_plot)
adjtreasplot <- treas_plot + coord_cartesian(xlim=c(as.Date("1995-01-01"),as.Date("2015-08-16")))
adjtreasplot
##ggplot for mean forecast coupon  
coup_plot <- ggplot(mnthregucoup, aes(x = as.Date(mnthregucoup$date), y = mnthregucoup$coupon))+ 
  geom_line(colour='black')+
  theme_minimal()+
  theme(legend.position = "bottom",
        axis.text.x = element_text(angle = 45),
        text = element_text(size = 11))+
  scale_x_date(date_breaks = "years", date_labels = "%Y")+
  xlab("\nYear")+
  ylab("Coupon Rates (%)\n")+
  scale_y_continuous(limits = c(0,15))+
  labs(title = "Average Regulated Utility Coupon Rate")
plot(coup_plot)
adjcoup_plot <- coup_plot + coord_cartesian(xlim=c(as.Date("1995-01-01"),as.Date("2015-08-16")))
adjcoup_plot

grid.arrange(adjtreasplot, adjcoup_plot, ncol = 1)
grid.arrange(adjtreasplot, adjcoup_plot, ncol = 2)

#adding spread data to monthly aggregate data frame
combtrescoup <- merge(mnthregucoup,mnthtreas,by = "date")
#for average treasury coupon use combtrescoup$avetreastot
combtrescoup <- data.frame(combtrescoup$date,combtrescoup$UST10,combtrescoup$coupon)
colnames(combtrescoup) <- c("date","UST10","coupon")
combtrescoup$spread <- SMA((combtrescoup$coupon -combtrescoup$UST10), n = 3)

##ggplot for spread of monthly coupon and treasury  
spread_plot <- ggplot(combtrescoup, aes(x = as.Date(combtrescoup$date), y = combtrescoup$spread))+ 
  geom_line(colour='black')+
  theme_minimal()+
  theme(legend.position = "bottom",
        axis.text.x = element_text(angle = 45),
        text = element_text(size = 11))+
  scale_x_date(date_breaks = "years", date_labels = "%Y")+
  xlab("\nYear")+
  ylab("Spread (%)\n")+
  labs(title = "Three Month Moving Average: Long-term Utility Coupon Rate vs 10 Year Treasury Spread")
plot(spread_plot)
adjspread_plot <- spread_plot + coord_cartesian(xlim=c(as.Date("1995-03-01"),as.Date("2015-08-16"))) +
                                scale_y_continuous(limits = c(0,6),
                                breaks = c(0,1,2,3,4,5,6),
                                labels = c(0,1,2,3,4,5,6))
adjspread_plot 

#writing graphs to ppt's for publication
#coupon plots
mydoc5 = pptx(  )
mydoc5 = addSlide(mydoc5, slide.layout = "Title and Content" )
mydoc5 = addTitle(mydoc5, "Plot examples" )
mydoc5 = addPlot(mydoc5, function( ) print(adj_aall), vector.graphic=TRUE)  
writeDoc(mydoc5, file = "E:/Commentaries/CouponComm/ALLDCoups.pptx" )
#spread power point file
mydoc6 = pptx(  )
mydoc6 = addSlide(mydoc6, slide.layout = "Title and Content" )
mydoc6 = addTitle(mydoc6, "Utility and Treasury Bond Spread" )
mydoc6 = addPlot(mydoc6, function( ) print(adjUStreas), vector.graphic=TRUE)  
writeDoc(mydoc6, file = "E:/Commentaries/CouponComm/USTreas.pptx" )
#spread power point file
mydoc7 = pptx(  )
mydoc7 = addSlide(mydoc7, slide.layout = "Title and Content" )
mydoc7 = addTitle(mydoc7, "Utility and Treasury Bond Spread" )
mydoc7 = addPlot(mydoc7, function( ) print(adjspread_plot), vector.graphic=TRUE)  
writeDoc(mydoc7, file = "E:/Commentaries/CouponComm/SpreadCouTreas.pptx" )
#full graph of coupon with debt and weighted average coupon
mydoc8 = pptx(  )
mydoc8 = addSlide(mydoc8, slide.layout = "Title and Content" )
mydoc8 = addTitle(mydoc8, "Coupon Debt and Weighted Average" )
mydoc8 = addPlot(mydoc8, function( ) print(grid.draw(rbind(ggplotGrob(adj_debtiss),ggplotGrob(adj_aall), size = "last"))), vector.graphic=TRUE)  
writeDoc(mydoc8, file = "E:/Commentaries/CouponComm/FullCoupW.pptx" )
#legend for weighted average coupon
mydoc9 = pptx(  )
mydoc9 = addSlide(mydoc9, slide.layout = "Title and Content" )
mydoc9 = addTitle(mydoc9, "Weighted Legend" )
mydoc9 = addPlot(mydoc9, function( ) print(adj_ywcoups), vector.graphic=TRUE)  
writeDoc(mydoc9, file = "E:/Commentaries/CouponComm/WLegend.pptx" )

#export of CSV data
#coupon data set 
write.csv(data.frame(regutil$MaturityDate,regutil$OfferingDate,regutil$Issuer,regutil$CouponatOffer,regutil$OfferingAmount,
                     regutil$term,regutil$fAmount,regutil$State),"E:/Commentaries/CouponComm/CouponData.csv")
#treasury data set
write.csv(data.frame(USTreas$Date,USTreas$UST20,USTreas$UST10,USTreas$UST5),
          "E:/Commentaries/CouponComm/TreasuryData.csv")
#spread data set
write.csv(data.frame(combtrescoup$date,combtrescoup$UST10,combtrescoup$coupon,combtrescoup$spread),
          "E:/Commentaries/CouponComm/SpreadData.csv")
